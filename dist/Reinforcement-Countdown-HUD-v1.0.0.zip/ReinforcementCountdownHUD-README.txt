Reinforcement Countdown HUD v1.0.0
================================

在《绝地潜兵2》任务中把「敌人增援冷却」显示成屏幕上的倒计时。
主机与客机都能显示。

依赖
  Bingus Shared Loader v15 或更新（API 1）。只开其中一个不起作用。
  支持 Steam 构建 25480438 / EXE 1.8.46015.0。

安装
  1. 关闭游戏
  2. 用 Arsenal 或 HD2MM 导入本 ZIP
  3. 启用它，并同时启用 Bingus Shared Loader
  4. Purge / Deploy
  5. 启动游戏，进入任务

显示规则
  READY            冷却清零，可以拉烟（绿色）
  剩余 > 2 分钟     绿色 MM:SS
  剩余 1-2 分钟     橙色 MM:SS
  剩余 < 1 分钟     红色 MM:SS
  增援进行中        不显示（那一刻的倒计时会误导）
  不在任务中        不显示

客机
  游戏只把 0..1 的归一化比例同步给客机，不给秒数。本模组用本机测出的比例
  下降率把它换算成秒数（数学上精确）。代价：进入任务或换段后约 4 秒内不
  显示数字——这段时间在测量下降率。宁可晚几秒，也不显示一个会读错的数字。

日志
  %LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\ReinforcementRadar.log

安全
  只读。源码与构建产物中都不存在写入游戏内存、改页保护、分配内存、
  加载代码或联网的调用；构建脚本会在发现任何一个时拒绝打包。
  全部改动只在内存读取侧，禁用模组即完全还原。

本模组是 Reinforcement Radar 的衍生作品（MIT，superSizzzz），
详见压缩包内的 THIRD_PARTY.md 与 LICENSE-Reinforcement-Radar。
